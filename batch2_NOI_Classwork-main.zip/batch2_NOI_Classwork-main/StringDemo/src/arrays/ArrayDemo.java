package arrays;

public class ArrayDemo {


    public static void main(String[] args) {

        int arr[] = {10,20,30,40};

        for (int x: arr)
        {
            System.out.println(x);
        }


    }//end main

}//end class
