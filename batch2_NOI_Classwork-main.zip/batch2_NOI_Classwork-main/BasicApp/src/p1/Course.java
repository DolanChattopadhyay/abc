package p1;

public class Course {

	int courseId;
	int noOfDays;
}
