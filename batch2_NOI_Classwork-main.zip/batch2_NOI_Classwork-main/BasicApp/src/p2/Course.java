package p2;

public class Course {

	int courseId;
	int noOfDays;
}
